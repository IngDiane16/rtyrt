//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var variable = 12345
let constante = 3.1416
variable = 25

var entero : Int = 23
var flotante : Float = 23.164
var doble : Double = 12.32
var booleano : Bool = true

var entero8 : Int8 = 127// es el máximo valor que puedes asignar
var entero16 : Int16 = 1231
var entero32 : Int32 = 8430219
var entero64 : Int64 = 12345

print(Int64.max)
var enteroSinSigno : UInt = 12345679876
var binario = 0b1011
var octal = 0o13
var hexadecimal = 0xB

var 😡 = "🤓"
print("🤓")
var pi = "Apple"
var numero1 = 23
var numero2 = 56
numero1 + numero2
65 - 23
76 / 8
24 * 2

numero2 += 2
numero2 *= 3
numero2 /= 5
numero1 -= 3

//Logico
numero1 > numero2
numero2 < numero1
numero1 >= numero2
numero2 <= numero1
numero1 != numero2

false || true
false || true
if numero2 > numero1
{
    print("Numero 2 es mayor")
    
}else if numero1 < 0
{
    print("Numero 1 es menos a cero")
}else{
    print("else")
}
var opcion = 4


switch opcion
{
case 27,4,5:
    print("Entró en la selección")
    break
case 1...10:
    break
case 4:
    print("Entró en otro")
case 1:
    break
case 4:
    print("Entró")
    break
case 5:
    print("caso 5")
default:
    break
}

for indice in 1...5
{
    print(indice)
}
for _ in 1...5//no nos importa el indice solo se realiza cinco veces
{
    print("Estamos en un for")
    
}
var indice = 0
while indice < 10 {
    indice += 1
}
//equivalente al do-while
repeat
{
    
}while(indice < 10)
var cadena1 = "Inicio"
var cadena2 : String = "Final"

var cadena3 = cadena1 + cadena2
var caracter : Character = "a"

cadena1.append(caracter)//Adds an element to the end of the collection.
cadena2.append(" Inicio")

var longitud = cadena1.count

if cadena1 == cadena2
{
    print("Son iguales")
}
else
{
    print("No son iguales")
}

cadena1.isEmpty
cadena1.hasPrefix("In")
cadena1.hasSuffix("icio")
var cadenaVariaLineas = """
Hola soy Diana y estoy aprendiendo Swift
"""
print(cadenaVariaLineas)
cadenaVariaLineas.contains("Diana")//Busca algùn parámetro en este caso fue Diana
cadena1.uppercased()//coloca las letras en mayúscula
cadena1.lowercased()//coloca las letras en minuscula





